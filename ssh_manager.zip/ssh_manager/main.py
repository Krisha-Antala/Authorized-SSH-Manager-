import sys  
from ssh_client import SSHClient
from logger import log_info, log_warning

clients = []

def display_menu():
    print("\n=== Authorized SSH Manager ===")
    print("1. List connected hosts")
    print("2. Add new SSH host")
    print("3. Execute command on host")
    print("4. Exit")

def list_hosts():
    if not clients:
        print("[!] No connected hosts.")
        return

    for idx, client in enumerate(clients):
        print(f"{idx + 1}. {client.host}:{client.port} ({client.user})")

def add_host():
    host = input("Host IP: ")
    port = int(input("SSH Port: "))
    user = input("Username: ")
    password = input("Password: ")

    client = SSHClient(host, port, user, password)

    if client.connect():
        clients.append(client)
        log_info(f"Connected to {host}:{port} as {user}")
        print("[+] SSH connection established.")
    else:
        log_warning(f"Failed SSH connection to {host}:{port}")
        print("[-] Connection failed.")

def execute_command():
    list_hosts()
    if not clients:
        return

    choice = int(input("Select host number: ")) - 1
    if choice < 0 or choice >= len(clients):
        print("Invalid selection.")
        return

    command = input("Enter command to execute: ")
    output = clients[choice].execute_command(command)

    log_info(f"Executed command on {clients[choice].host}: {command}")
    print("\n--- Command Output ---")
    print(output)

def main():
    while True:
        display_menu()
        option = input("Select option: ")

        if option == "1":
            list_hosts()
        elif option == "2":
            add_host()
        elif option == "3":
            execute_command()
        elif option == "4":
            print("Exiting...")
            sys.exit(0)
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()
