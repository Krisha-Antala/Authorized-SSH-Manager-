import pexpect.pxssh as pxssh
import time

class SSHClient:
    def __init__(self, host, port, user, password):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.session = None

    def connect(self):
        try:
            self.session = pxssh.pxssh(timeout=10)
            self.session.login(
                self.host,
                self.user,
                self.password,
                port=self.port,
                auto_prompt_reset=False
            )
            return True
        except Exception as e:
            print(f"[!] SSH connection failed: {e}")
            return False

    def execute_command(self, command):
        if not self.session:
            return None

        self.session.sendline(command)
        self.session.prompt()
        output = self.session.before.decode(errors="ignore")
        return output

    def disconnect(self):
        if self.session:
            self.session.logout()
            self.session = None
